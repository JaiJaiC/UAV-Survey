class Data:
    def __init__(self):

        # 该字典里为self变量数据
        self.self_data_dict = {
            'step': 0.0,
            'fighter_side': 0.0,
            'control_mode': 0.0,

            'left_bullet': 0.0,
            'left_missile_close': 0.0,
            'left_missile_mid': 0.0,
            'left_bloods': 0.0,

            'Longitude': 0.0,
            'Latitude': 0.0,
            'Altitude': 0.0,

            'NorthVelocity': 0.0,
            'EastVelocity': 0.0,
            'VerticalVelocity': 0.0,

            'NorthAcceleration': 0.0,
            'EastAcceleration': 0.0,
            'VerticalAcceleration': 0.0,

            'RollAngle': 0.0,
            'PitchAngle': 0.0,
            'YawAngle': 0.0,

            'PathPitchAngle': 0.0,
            'PathYawAngle': 0.0,

            'AttackAngle': 0.0,
            'SideslipAngle': 0.0,

            'RollRate': 0.0,
            'PitchRate': 0.0,
            'YawRate': 0.0,

            'NormalLoad': 0.0,
            'LateralLoad': 0.0,
            'LongitudeinalLoad': 0.0,

            'NormalVelocity': 0.0,
            'LateralVelocity': 0.0,
            'LongitudianlVelocity': 0.0,

            'TrueAirSpeed': 0.0,
            'IndicatedAirSpeed': 0.0,
            'GroundSpeed': 0.0,
            'MachNumber': 0.0,
            'NumberofFuel': 0.0,
            'Thrust': 0.0,

            'MissileClose1State': 0.0,
            'MissileClose2State': 0.0,
            'MissileClose3State': 0.0,
            'MissileClose4State': 0.0,

            'MissileMid1State': 0.0,
            'MissileMid2State': 0.0,
            'MissileMid3State': 0.0,
            'MissileMid4State': 0.0,
        }

        # 雷达探测信息
        self.radar_data_dict = {
            'friend_is_catch': 0.0,
            'friend_EleAngle': 0.0,
            'friend_AziAngle': 0.0,
            'friend_Distance': 0.0,
            'friend_NorthVelocity': 0.0,
            'friend_EastVelocity': 0.0,
            'friend_VerticalVelocity': 0.0,

            'target1_Index': 0.0,
            'target1_is_catch': 0.0,
            'target1_EleAngle': 0.0,
            'target1_AziAngle': 0.0,
            'target1_Distance': 0.0,
            'target1_NorthVelocity': 0.0,
            'target1_EastVelocity': 0.0,
            'target1_VerticalVelocity': 0.0,

            'target2_Index': 0.0,
            'target2_is_catch': 0.0,
            'target2_EleAngle': 0.0,
            'target2_AziAngle': 0.0,
            'target2_Distance': 0.0,
            'target2_NorthVelocity': 0.0,
            'target2_EastVelocity': 0.0,
            'target2_VerticalVelocity': 0.0,
        }

        # 预警机信息
        self.AWACS_data_dict = {
            'friend_Longitude': 0.0,
            'friend_Latitude': 0.0,
            'friend_Altitude': 0.0,
            'friend_Survive': 0.0,

            'target1_Index': 0.0,
            'target1_Longitude': 0.0,
            'target1_Latitude': 0.0,
            'target1_Altitude': 0.0,
            'target1_Survive': 0.0,

            'target2_Index': 0.0,
            'target2_Longitude': 0.0,
            'target2_Latitude': 0.0,
            'target2_Altitude': 0.0,
            'target2_Survive': 0.0,
        }

        # 告警信息
        self.alert_data_dict = {
            'emergency_num': 0.0,
            'emergency_EleAngle': 0.0,
            'emergency_AziAngle': 0.0,
            'emergency_missile_num_close': 0.0,
            'emergency_missile_EleAngle_close': 0.0,
            'emergency_missile_AziAngle_close': 0.0,
            'emergency_missile_num_mid': 0.0,
            'emergency_missile_EleAngle_mid': 0.0,
            'emergency_missile_AziAngle_mid': 0.0,
        }

        # 近距透明信息
        self.close_data_dict = {
            'friend_is_visible': 0.0,
            'friend_EleAngle': 0.0,
            'friend_AziAngle': 0.0,
            'friend_Distance': 0.0,

            'target1_Index': 0.0,
            'target1_is_visible': 0.0,
            'target1_EleAngle': 0.0,
            'target1_AziAngle': 0.0,
            'target1_Distance': 0.0,

            'target2_Index': 0.0,
            'target2_is_visible': 0.0,
            'target2_EleAngle': 0.0,
            'target2_AziAngle': 0.0,
            'target2_Distance': 0.0,
        }